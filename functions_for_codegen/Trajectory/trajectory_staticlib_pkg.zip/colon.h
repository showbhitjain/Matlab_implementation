//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: colon.h
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 26-Oct-2024 20:50:12
//

#ifndef COLON_H
#define COLON_H

// Include Files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace trajectoryGeneration {
namespace coder {
void eml_float_colon(double d, double b, ::coder::array<double, 2U> &y);

}
} // namespace trajectoryGeneration

#endif
//
// File trailer for colon.h
//
// [EOF]
//
