//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: Jacobi_final_link.cpp
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 01-Mar-2025 01:36:28
//

// Include Files
#include "Jacobi_final_link.h"
#include "inverseKinematicsOAModified_rtwutil.h"
#include "inverseKinematicsOAModified_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <cstring>

// Function Definitions
//
// function J = Jacobi_final_link(in1)
//
// Jacobi_final_link
//     J = Jacobi_final_link(IN1)
//
// Arguments    : const coder::array<double, 2U> &in1
//                double J[42]
// Return Type  : void
//
void Jacobi_final_link(const coder::array<double, 2U> &in1, double J[42])
{
  static rtBoundsCheckInfo ab_emlrtBCI{
      -1,                  // iFirst
      -1,                  // iLast
      11,                  // lineNo
      16,                  // colNo
      "in1",               // aName
      "Jacobi_final_link", // fName
      "/home/shobhit/ShobhitRobotModelling/robotmodelling/"
      "Matlab_implementation/functions_for_codegen/"
      "obstacleAvoidanceOptmisationModif"
      "ied/Jacobi_final_link.m", // pName
      0                          // checkKind
  };
  static rtBoundsCheckInfo bb_emlrtBCI{
      -1,                  // iFirst
      -1,                  // iLast
      12,                  // lineNo
      16,                  // colNo
      "in1",               // aName
      "Jacobi_final_link", // fName
      "/home/shobhit/ShobhitRobotModelling/robotmodelling/"
      "Matlab_implementation/functions_for_codegen/"
      "obstacleAvoidanceOptmisationModif"
      "ied/Jacobi_final_link.m", // pName
      0                          // checkKind
  };
  static rtBoundsCheckInfo cb_emlrtBCI{
      -1,                  // iFirst
      -1,                  // iLast
      13,                  // lineNo
      16,                  // colNo
      "in1",               // aName
      "Jacobi_final_link", // fName
      "/home/shobhit/ShobhitRobotModelling/robotmodelling/"
      "Matlab_implementation/functions_for_codegen/"
      "obstacleAvoidanceOptmisationModif"
      "ied/Jacobi_final_link.m", // pName
      0                          // checkKind
  };
  static rtBoundsCheckInfo w_emlrtBCI{
      -1,                  // iFirst
      -1,                  // iLast
      8,                   // lineNo
      16,                  // colNo
      "in1",               // aName
      "Jacobi_final_link", // fName
      "/home/shobhit/ShobhitRobotModelling/robotmodelling/"
      "Matlab_implementation/functions_for_codegen/"
      "obstacleAvoidanceOptmisationModif"
      "ied/Jacobi_final_link.m", // pName
      0                          // checkKind
  };
  static rtBoundsCheckInfo x_emlrtBCI{
      -1,                  // iFirst
      -1,                  // iLast
      9,                   // lineNo
      16,                  // colNo
      "in1",               // aName
      "Jacobi_final_link", // fName
      "/home/shobhit/ShobhitRobotModelling/robotmodelling/"
      "Matlab_implementation/functions_for_codegen/"
      "obstacleAvoidanceOptmisationModif"
      "ied/Jacobi_final_link.m", // pName
      0                          // checkKind
  };
  static rtBoundsCheckInfo y_emlrtBCI{
      -1,                  // iFirst
      -1,                  // iLast
      10,                  // lineNo
      16,                  // colNo
      "in1",               // aName
      "Jacobi_final_link", // fName
      "/home/shobhit/ShobhitRobotModelling/robotmodelling/"
      "Matlab_implementation/functions_for_codegen/"
      "obstacleAvoidanceOptmisationModif"
      "ied/Jacobi_final_link.m", // pName
      0                          // checkKind
  };
  double et41;
  double et43;
  double t10;
  double t102;
  double t103;
  double t104;
  double t106;
  double t107;
  double t109_tmp;
  double t11;
  double t113;
  double t114;
  double t115;
  double t119;
  double t12;
  double t120;
  double t13;
  double t14;
  double t148;
  double t149;
  double t15;
  double t157;
  double t158;
  double t159;
  double t16;
  double t160;
  double t162;
  double t166;
  double t17;
  double t171;
  double t172;
  double t18;
  double t187;
  double t188;
  double t19;
  double t192;
  double t199;
  double t2;
  double t20;
  double t202;
  double t202_tmp;
  double t203;
  double t204;
  double t204_tmp;
  double t207;
  double t21;
  double t213;
  double t214;
  double t215;
  double t22;
  double t222;
  double t23;
  double t235;
  double t237;
  double t237_tmp;
  double t238;
  double t238_tmp;
  double t239;
  double t242;
  double t244;
  double t245;
  double t248;
  double t249;
  double t254;
  double t255;
  double t255_tmp;
  double t257;
  double t257_tmp;
  double t258;
  double t259_tmp;
  double t261;
  double t264;
  double t266;
  double t267;
  double t269;
  double t27;
  double t271;
  double t274_tmp;
  double t276;
  double t277;
  double t283;
  double t285;
  double t287_tmp;
  double t291;
  double t292;
  double t297;
  double t299;
  double t299_tmp;
  double t3;
  double t301;
  double t302;
  double t303_tmp_tmp;
  double t308_tmp;
  double t311_tmp;
  double t312;
  double t313;
  double t314;
  double t314_tmp;
  double t315;
  double t315_tmp;
  double t317;
  double t317_tmp;
  double t318;
  double t318_tmp;
  double t328;
  double t328_tmp;
  double t329;
  double t329_tmp;
  double t333;
  double t335;
  double t36;
  double t4;
  double t43;
  double t5;
  double t54;
  double t57;
  double t58;
  double t59;
  double t6;
  double t60;
  double t61;
  double t62;
  double t63;
  double t64;
  double t67;
  double t7;
  double t70;
  double t71;
  double t8;
  double t87;
  double t88;
  double t94;
  double t95_tmp;
  double t96;
  double theta1;
  double theta2;
  double theta3;
  double theta4;
  double theta5;
  double theta6;
  //     This function was generated by the Symbolic Math Toolbox version 23.2.
  //     08-Nov-2024 19:20:44
  // 'Jacobi_final_link:8' theta1 = in1(:,1);
  if (in1.size(1) < 1) {
    rtDynamicBoundsError(1, 1, in1.size(1), w_emlrtBCI);
  }
  theta1 = in1[0];
  // 'Jacobi_final_link:9' theta2 = in1(:,2);
  if (in1.size(1) < 2) {
    rtDynamicBoundsError(2, 1, in1.size(1), x_emlrtBCI);
  }
  theta2 = in1[1];
  // 'Jacobi_final_link:10' theta3 = in1(:,3);
  if (in1.size(1) < 3) {
    rtDynamicBoundsError(3, 1, in1.size(1), y_emlrtBCI);
  }
  theta3 = in1[2];
  // 'Jacobi_final_link:11' theta4 = in1(:,4);
  if (in1.size(1) < 4) {
    rtDynamicBoundsError(4, 1, in1.size(1), ab_emlrtBCI);
  }
  theta4 = in1[3];
  // 'Jacobi_final_link:12' theta5 = in1(:,5);
  if (in1.size(1) < 5) {
    rtDynamicBoundsError(5, 1, in1.size(1), bb_emlrtBCI);
  }
  theta5 = in1[4];
  // 'Jacobi_final_link:13' theta6 = in1(:,6);
  if (in1.size(1) < 6) {
    rtDynamicBoundsError(6, 1, in1.size(1), cb_emlrtBCI);
  }
  theta6 = in1[5];
  // 'Jacobi_final_link:14' t2 = cos(theta1);
  t2 = std::cos(theta1);
  // 'Jacobi_final_link:15' t3 = cos(theta2);
  t3 = std::cos(theta2);
  // 'Jacobi_final_link:16' t4 = cos(theta3);
  t4 = std::cos(theta3);
  // 'Jacobi_final_link:17' t5 = cos(theta4);
  t5 = std::cos(theta4);
  // 'Jacobi_final_link:18' t6 = cos(theta5);
  t6 = std::cos(theta5);
  // 'Jacobi_final_link:19' t7 = cos(theta6);
  t7 = std::cos(theta6);
  // 'Jacobi_final_link:20' t8 = sin(theta1);
  t8 = std::sin(theta1);
  // 'Jacobi_final_link:21' t9 = sin(theta2);
  theta1 = std::sin(theta2);
  // 'Jacobi_final_link:22' t10 = sin(theta3);
  t10 = std::sin(theta3);
  // 'Jacobi_final_link:23' t11 = sin(theta4);
  t11 = std::sin(theta4);
  // 'Jacobi_final_link:24' t12 = sin(theta5);
  t12 = std::sin(theta5);
  // 'Jacobi_final_link:25' t13 = sin(theta6);
  t13 = std::sin(theta6);
  // 'Jacobi_final_link:26' t14 = t2.*t3;
  t14 = t2 * t3;
  // 'Jacobi_final_link:27' t15 = t2.*t4;
  t15 = t2 * t4;
  // 'Jacobi_final_link:28' t16 = t2.*t9;
  t16 = t2 * theta1;
  // 'Jacobi_final_link:29' t17 = t3.*t8;
  t17 = t3 * t8;
  // 'Jacobi_final_link:30' t18 = t2.*t10;
  t18 = t2 * t10;
  // 'Jacobi_final_link:31' t19 = t4.*t8;
  t19 = t4 * t8;
  // 'Jacobi_final_link:32' t20 = t4.*t9;
  t20 = t4 * theta1;
  // 'Jacobi_final_link:33' t21 = t8.*t9;
  t21 = t8 * theta1;
  // 'Jacobi_final_link:34' t22 = t8.*t10;
  t22 = t8 * t10;
  // 'Jacobi_final_link:35' t23 = t9.*t10;
  t23 = theta1 * t10;
  // 'Jacobi_final_link:36' t32 = t2.*6.123233995736766e-17;
  // 'Jacobi_final_link:37' t33 = t3.*6.123233995736766e-17;
  theta1 = t3 * 6.123233995736766E-17;
  // 'Jacobi_final_link:38' t34 = t4.*6.123233995736766e-17;
  theta5 = t4 * 6.123233995736766E-17;
  // 'Jacobi_final_link:39' t35 = t8.*6.123233995736766e-17;
  // 'Jacobi_final_link:40' t36 = t10.*6.123233995736766e-17;
  t36 = t10 * 6.123233995736766E-17;
  // 'Jacobi_final_link:41' t51 = t3.*t4.*(-6.123233995736766e-17);
  // 'Jacobi_final_link:42' t54 = t10.*5.051668046482832e-18;
  t54 = t10 * 5.0516680464828323E-18;
  // 'Jacobi_final_link:43' t56 = t3.*t10.*(-5.051668046482832e-18);
  // 'Jacobi_final_link:44' t69 = t2.*3.749399456654644e-33;
  // 'Jacobi_final_link:45' t70 = t3.*3.749399456654644e-33;
  t70 = t3 * 3.749399456654644E-33;
  // 'Jacobi_final_link:46' t71 = t4.*3.749399456654644e-33;
  t71 = t4 * 3.749399456654644E-33;
  // 'Jacobi_final_link:47' t72 = t3+3.749399456654644e-33;
  // 'Jacobi_final_link:48' t73 = t8.*3.749399456654644e-33;
  // 'Jacobi_final_link:49' t118 = t2.*2.295845021658468e-49;
  // 'Jacobi_final_link:50' t119 = t3.*2.295845021658468e-49;
  t119 = t3 * 2.2958450216584679E-49;
  // 'Jacobi_final_link:51' t120 = t4.*2.295845021658468e-49;
  t120 = t4 * 2.2958450216584679E-49;
  // 'Jacobi_final_link:52' t121 = t8.*2.295845021658468e-49;
  // 'Jacobi_final_link:53' t163 = t2.*1.405799628556214e-65;
  // 'Jacobi_final_link:54' t164 = t8.*1.405799628556214e-65;
  // 'Jacobi_final_link:55' t171 = t3.*1.504205602555149e-66;
  t171 = t3 * 1.504205602555149E-66;
  // 'Jacobi_final_link:56' t172 = t4.*1.504205602555149e-66;
  t172 = t4 * 1.504205602555149E-66;
  // 'Jacobi_final_link:57' et1 = t3;
  // 'Jacobi_final_link:58' et2 = 1.439769391355383e-33;
  // 'Jacobi_final_link:59' t187 = et1.*et2;
  t187 = t3 * 1.439769391355383E-33;
  // 'Jacobi_final_link:60' et3 = t4;
  // 'Jacobi_final_link:61' et4 = 1.439769391355383e-33;
  // 'Jacobi_final_link:62' t188 = et3.*et4;
  t188 = t4 * 1.439769391355383E-33;
  // 'Jacobi_final_link:63' et5 = t2;
  // 'Jacobi_final_link:64' et6 = 9.210602882143395e-83;
  // 'Jacobi_final_link:65' t205 = et5.*et6;
  // 'Jacobi_final_link:66' et7 = t8;
  // 'Jacobi_final_link:67' et8 = 9.210602882143395e-83;
  // 'Jacobi_final_link:68' t206 = et7.*et8;
  // 'Jacobi_final_link:69' et9 = t3;
  // 'Jacobi_final_link:70' et10 = 3.16e-1;
  // 'Jacobi_final_link:71' t220 = et9.*et10;
  // 'Jacobi_final_link:72' et11 = t2;
  // 'Jacobi_final_link:73' et12 = 8.816044883168516e-50;
  // 'Jacobi_final_link:74' t223 = et11.*et12;
  // 'Jacobi_final_link:75' et13 = t8;
  // 'Jacobi_final_link:76' et14 = 8.816044883168516e-50;
  // 'Jacobi_final_link:77' t224 = et13.*et14;
  // 'Jacobi_final_link:78' et15 = t2;
  // 'Jacobi_final_link:79' et16 = 1.934941942652818e-17;
  // 'Jacobi_final_link:80' t239 = et15.*et16;
  t239 = t2 * 1.9349419426528181E-17;
  // 'Jacobi_final_link:81' et17 = t8;
  // 'Jacobi_final_link:82' et18 = 1.934941942652818e-17;
  // 'Jacobi_final_link:83' t240 = et17.*et18;
  // 'Jacobi_final_link:84' t24 = -t15;
  // 'Jacobi_final_link:85' t25 = -t21;
  // 'Jacobi_final_link:86' t26 = -t23;
  // 'Jacobi_final_link:87' t27 = t18.*(3.3e+1./4.0e+2);
  t27 = t18 * 0.0825;
  // 'Jacobi_final_link:88' t28 = t20.*(3.3e+1./4.0e+2);
  // 'Jacobi_final_link:89' t29 = t22.*(3.3e+1./4.0e+2);
  // 'Jacobi_final_link:90' t37 = -t34;
  // 'Jacobi_final_link:91' t38 = -t35;
  // 'Jacobi_final_link:92' t39 = -t36;
  // 'Jacobi_final_link:93' t40 = t14.*6.123233995736766e-17;
  theta2 = t14 * 6.123233995736766E-17;
  // 'Jacobi_final_link:94' t41 = t15.*6.123233995736766e-17;
  // 'Jacobi_final_link:95' t42 = t4.*t33;
  // 'Jacobi_final_link:96' t43 = t16.*6.123233995736766e-17;
  t43 = t16 * 6.123233995736766E-17;
  // 'Jacobi_final_link:97' t44 = t17.*6.123233995736766e-17;
  // 'Jacobi_final_link:98' t45 = t19.*6.123233995736766e-17;
  // 'Jacobi_final_link:99' t46 = t10.*t33;
  // 'Jacobi_final_link:100' t47 = t21.*6.123233995736766e-17;
  theta4 = t21 * 6.123233995736766E-17;
  // 'Jacobi_final_link:101' t48 = t23.*6.123233995736766e-17;
  // 'Jacobi_final_link:102' t74 = -t71;
  // 'Jacobi_final_link:103' t75 = -t73;
  // 'Jacobi_final_link:104' t76 = t14.*3.749399456654644e-33;
  // 'Jacobi_final_link:105' t77 = t15.*3.749399456654644e-33;
  // 'Jacobi_final_link:106' t78 = t4.*t70;
  // 'Jacobi_final_link:107' t79 = t16.*3.749399456654644e-33;
  // 'Jacobi_final_link:108' t80 = t17.*3.749399456654644e-33;
  // 'Jacobi_final_link:109' t81 = t19.*3.749399456654644e-33;
  // 'Jacobi_final_link:110' t82 = t21.*3.749399456654644e-33;
  // 'Jacobi_final_link:111' t83 = t23.*3.749399456654644e-33;
  // 'Jacobi_final_link:112' t87 = t5.*t72;
  t87 = t5 * (t3 + 3.749399456654644E-33);
  // 'Jacobi_final_link:113' t88 = t11.*t72;
  t88 = t11 * (t3 + 3.749399456654644E-33);
  // 'Jacobi_final_link:114' t95 = t23+t34+t51;
  t95_tmp = t3 * t4;
  theta6 = (t23 + theta5) + t95_tmp * -6.123233995736766E-17;
  // 'Jacobi_final_link:115' t122 = -t120;
  // 'Jacobi_final_link:116' t123 = -t121;
  // 'Jacobi_final_link:117' t124 = t14.*2.295845021658468e-49;
  // 'Jacobi_final_link:118' t125 = t4.*t119;
  // 'Jacobi_final_link:119' t126 = t16.*2.295845021658468e-49;
  // 'Jacobi_final_link:120' t127 = t17.*2.295845021658468e-49;
  // 'Jacobi_final_link:121' t128 = t21.*2.295845021658468e-49;
  // 'Jacobi_final_link:122' t129 = t15.*2.45655417317456e-50;
  // 'Jacobi_final_link:123' t131 = t19.*2.45655417317456e-50;
  // 'Jacobi_final_link:124' t132 = t23.*2.45655417317456e-50;
  // 'Jacobi_final_link:125' t148 = t15.*2.351321854362918e-17;
  t148 = t15 * 2.3513218543629179E-17;
  // 'Jacobi_final_link:126' t149 = t19.*2.351321854362918e-17;
  t149 = t19 * 2.3513218543629179E-17;
  // 'Jacobi_final_link:127' t151 = t23.*2.351321854362918e-17;
  // 'Jacobi_final_link:128' t167 = -t164;
  // 'Jacobi_final_link:129' t168 = t14.*1.405799628556214e-65;
  // 'Jacobi_final_link:130' t169 = t17.*1.405799628556214e-65;
  // 'Jacobi_final_link:131' t173 = -t172;
  // 'Jacobi_final_link:132' t174 = t16.*1.504205602555149e-66;
  // 'Jacobi_final_link:133' t175 = t21.*1.504205602555149e-66;
  // 'Jacobi_final_link:134' t176 = t4.*t171;
  // 'Jacobi_final_link:135' t189 = -t188;
  // 'Jacobi_final_link:136' et19 = t16;
  // 'Jacobi_final_link:137' et20 = 1.439769391355383e-33;
  // 'Jacobi_final_link:138' t190 = et19.*et20;
  // 'Jacobi_final_link:139' et21 = t21;
  // 'Jacobi_final_link:140' et22 = 1.439769391355383e-33;
  // 'Jacobi_final_link:141' t191 = et21.*et22;
  // 'Jacobi_final_link:142' t192 = t4.*t187;
  t192 = t4 * t187;
  // 'Jacobi_final_link:143' t209 = -t206;
  // 'Jacobi_final_link:144' et23 = t14;
  // 'Jacobi_final_link:145' et24 = 9.210602882143395e-83;
  // 'Jacobi_final_link:146' t210 = et23.*et24;
  // 'Jacobi_final_link:147' et25 = t17;
  // 'Jacobi_final_link:148' et26 = 9.210602882143395e-83;
  // 'Jacobi_final_link:149' t211 = et25.*et26;
  // 'Jacobi_final_link:150' et27 = t16;
  // 'Jacobi_final_link:151' et28 = 3.16e-1;
  // 'Jacobi_final_link:152' t221 = et27.*et28;
  // 'Jacobi_final_link:153' et29 = t21;
  // 'Jacobi_final_link:154' et30 = 3.16e-1;
  // 'Jacobi_final_link:155' t222 = et29.*et30;
  t222 = t21 * 0.316;
  // 'Jacobi_final_link:156' t225 = -t224;
  // 'Jacobi_final_link:157' et31 = t14;
  // 'Jacobi_final_link:158' et32 = 8.816044883168516e-50;
  // 'Jacobi_final_link:159' t226 = et31.*et32;
  // 'Jacobi_final_link:160' et33 = t17;
  // 'Jacobi_final_link:161' et34 = 8.816044883168516e-50;
  // 'Jacobi_final_link:162' t227 = et33.*et34;
  // 'Jacobi_final_link:163' t241 = -t240;
  // 'Jacobi_final_link:164' et35 = t14;
  // 'Jacobi_final_link:165' et36 = 1.934941942652818e-17;
  // 'Jacobi_final_link:166' t242 = et35.*et36;
  t242 = t14 * 1.9349419426528181E-17;
  // 'Jacobi_final_link:167' et37 = t17;
  // 'Jacobi_final_link:168' et38 = 1.934941942652818e-17;
  // 'Jacobi_final_link:169' t243 = et37.*et38;
  // 'Jacobi_final_link:170' t30 = -t28;
  // 'Jacobi_final_link:171' t31 = -t29;
  // 'Jacobi_final_link:172' t49 = -t40;
  // 'Jacobi_final_link:173' t50 = -t41;
  // 'Jacobi_final_link:174' t52 = -t47;
  // 'Jacobi_final_link:175' t53 = -t48;
  // 'Jacobi_final_link:176' t57 = t16+t44;
  t57 = t16 + t17 * 6.123233995736766E-17;
  // 'Jacobi_final_link:177' t58 = t17+t43;
  t58 = t17 + t43;
  // 'Jacobi_final_link:178' t60 = t25+t40;
  t60 = -t21 + theta2;
  // 'Jacobi_final_link:179' t84 = -t76;
  // 'Jacobi_final_link:180' t85 = -t77;
  // 'Jacobi_final_link:181' t86 = -t83;
  // 'Jacobi_final_link:182' t89 = t88.*(3.3e+1./4.0e+2);
  // 'Jacobi_final_link:183' t98 = t20+t39+t46;
  theta3 = (t20 - t36) + t10 * theta1;
  // 'Jacobi_final_link:184' t130 = -t124;
  // 'Jacobi_final_link:185' t133 = -t129;
  // 'Jacobi_final_link:186' t134 = -t132;
  // 'Jacobi_final_link:187' t135 = t87.*6.123233995736766e-17;
  // 'Jacobi_final_link:188' t142 = t5.*t95.*6.123233995736766e-17;
  // 'Jacobi_final_link:189' t144 = t11.*t95.*6.123233995736766e-17;
  // 'Jacobi_final_link:190' t146 = t11.*t95.*5.051668046482832e-18;
  // 'Jacobi_final_link:191' t152 = -t148;
  // 'Jacobi_final_link:192' t154 = -t151;
  // 'Jacobi_final_link:193' t170 = -t168;
  // 'Jacobi_final_link:194' t177 = t87.*4.011857418620469e-34;
  // 'Jacobi_final_link:195' t183 = t5.*t95.*3.749399456654644e-33;
  // 'Jacobi_final_link:196' t199 = t87.*3.84e-1;
  t199 = t87 * 0.384;
  // 'Jacobi_final_link:197' t212 = -t210;
  // 'Jacobi_final_link:198' t219 = t5.*t95.*2.45655417317456e-50;
  // 'Jacobi_final_link:199' t228 = -t226;
  // 'Jacobi_final_link:200' t238 = t5.*t95.*2.351321854362918e-17;
  t238_tmp = t5 * theta6;
  t238 = t238_tmp * 2.3513218543629179E-17;
  // 'Jacobi_final_link:201' t244 = t26+t33+t37+t42+2.295845021658468e-49;
  t244 = (((-t23 + theta1) - theta5) + t4 * theta1) + 2.2958450216584679E-49;
  // 'Jacobi_final_link:202' t59 = t14+t52;
  t59 = t14 - theta4;
  // 'Jacobi_final_link:203' t61 = t4.*t58;
  t61 = t4 * t58;
  // 'Jacobi_final_link:204' t62 = t10.*t58;
  t62 = t10 * t58;
  // 'Jacobi_final_link:205' t90 = -t89;
  // 'Jacobi_final_link:206' t91 = t34.*t57;
  // 'Jacobi_final_link:207' t92 = t36.*t57;
  // 'Jacobi_final_link:208' t93 = t36.*t58;
  // 'Jacobi_final_link:209' t94 = t21+t32+t49;
  t94 = (t21 + t2 * 6.123233995736766E-17) - theta2;
  // 'Jacobi_final_link:210' t96 = t38+t57;
  t96 = -(t8 * 6.123233995736766E-17) + t57;
  // 'Jacobi_final_link:211' t99 = t34.*t60;
  // 'Jacobi_final_link:212' t100 = t36.*t60;
  // 'Jacobi_final_link:213' t101 = t4.*t60.*(-6.123233995736766e-17);
  // 'Jacobi_final_link:214' t105 = t5.*t98;
  theta2 = t5 * theta3;
  // 'Jacobi_final_link:215' t107 = t11.*t98;
  t107 = t11 * theta3;
  // 'Jacobi_final_link:216' t109 = t10.*t57.*(-5.051668046482832e-18);
  t109_tmp = t10 * t57;
  // 'Jacobi_final_link:217' t112 = t54.*t60;
  // 'Jacobi_final_link:218' t136 = t57.*t71;
  // 'Jacobi_final_link:219' t140 = t4.*t60.*(-3.749399456654644e-33);
  // 'Jacobi_final_link:220' t147 = -t146;
  // 'Jacobi_final_link:221' t178 = t57.*t120;
  // 'Jacobi_final_link:222' t182 = t4.*t60.*(-2.295845021658468e-49);
  // 'Jacobi_final_link:223' t216 = t57.*t172;
  // 'Jacobi_final_link:224' t218 = t4.*t60.*(-1.504205602555149e-66);
  // 'Jacobi_final_link:225' t235 = t57.*t188;
  t235 = t57 * t188;
  // 'Jacobi_final_link:226' t236 = t60.*t188;
  // 'Jacobi_final_link:227' et39 = t4.*t60;
  // 'Jacobi_final_link:228' et40 = -1.439769391355383e-33;
  // 'Jacobi_final_link:229' t237 = et39.*et40;
  t237_tmp = t4 * t60;
  t237 = t237_tmp * -1.439769391355383E-33;
  // 'Jacobi_final_link:230' t245 = t6.*t244;
  t245 = t6 * t244;
  // 'Jacobi_final_link:231' t246 = t12.*t244;
  // 'Jacobi_final_link:232' t63 = t4.*t59;
  t63 = t4 * t59;
  // 'Jacobi_final_link:233' t64 = t10.*t59;
  t64 = t10 * t59;
  // 'Jacobi_final_link:234' t65 = -t62;
  // 'Jacobi_final_link:235' t67 = t61.*(3.3e+1./4.0e+2);
  t67 = t61 * 0.0825;
  // 'Jacobi_final_link:236' t97 = t36.*t59;
  // 'Jacobi_final_link:237' t102 = t5.*t94;
  t102 = t5 * t94;
  // 'Jacobi_final_link:238' t103 = t5.*t96;
  t103 = t5 * t96;
  // 'Jacobi_final_link:239' t104 = t11.*t94;
  t104 = t11 * t94;
  // 'Jacobi_final_link:240' t106 = t11.*t96;
  t106 = t11 * t96;
  // 'Jacobi_final_link:241' t110 = -t105;
  // 'Jacobi_final_link:242' t114 = t105.*(3.3e+1./4.0e+2);
  t114 = theta2 * 0.0825;
  // 'Jacobi_final_link:243' t137 = t62.*3.749399456654644e-33;
  // 'Jacobi_final_link:244' t145 = t107.*6.123233995736766e-17;
  // 'Jacobi_final_link:245' t153 = t18+t61+t100;
  theta1 = (t18 + t61) + t36 * t60;
  // 'Jacobi_final_link:246' t179 = t62.*2.45655417317456e-50;
  // 'Jacobi_final_link:247' t186 = t107.*4.011857418620469e-34;
  // 'Jacobi_final_link:248' t203 = t62.*2.351321854362918e-17;
  t203 = t62 * 2.3513218543629179E-17;
  // 'Jacobi_final_link:249' t215 = t107.*3.84e-1;
  t215 = t107 * 0.384;
  // 'Jacobi_final_link:250' t247 = -t246;
  // 'Jacobi_final_link:251' t254 = t245.*6.55186037543834e-18;
  t254 = t245 * 6.55186037543834E-18;
  // 'Jacobi_final_link:252' t258 = t87+t107+t142;
  t258 = (t87 + t107) + t238_tmp * 6.123233995736766E-17;
  // 'Jacobi_final_link:253' t269 = t24+t47+t62+t69+t84+t101;
  t269 = ((((-t15 + theta4) + t62) + t2 * 3.749399456654644E-33) -
          t14 * 3.749399456654644E-33) +
         t237_tmp * -6.123233995736766E-17;
  // 'Jacobi_final_link:254' t66 = -t63;
  // 'Jacobi_final_link:255' t68 = t63.*(3.3e+1./4.0e+2);
  // 'Jacobi_final_link:256' t111 = -t106;
  // 'Jacobi_final_link:257' t113 = t104.*(3.3e+1./4.0e+2);
  t113 = t104 * 0.0825;
  // 'Jacobi_final_link:258' t115 = t106.*(3.3e+1./4.0e+2);
  t115 = t106 * 0.0825;
  // 'Jacobi_final_link:259' t138 = t64.*3.749399456654644e-33;
  // 'Jacobi_final_link:260' t141 = t102.*6.123233995736766e-17;
  // 'Jacobi_final_link:261' t143 = t103.*6.123233995736766e-17;
  // 'Jacobi_final_link:262' t150 = t19+t64+t91;
  theta4 = (t19 + t64) + theta5 * t57;
  // 'Jacobi_final_link:263' t156 = t15+t65+t99;
  theta3 = (t15 - t62) + theta5 * t60;
  // 'Jacobi_final_link:264' t157 = t5.*t153;
  t157 = t5 * theta1;
  // 'Jacobi_final_link:265' t158 = t11.*t153;
  t158 = t11 * theta1;
  // 'Jacobi_final_link:266' t181 = t64.*2.45655417317456e-50;
  // 'Jacobi_final_link:267' t184 = t102.*4.011857418620469e-34;
  // 'Jacobi_final_link:268' t185 = t103.*4.011857418620469e-34;
  // 'Jacobi_final_link:269' t207 = t64.*2.351321854362918e-17;
  t207 = t64 * 2.3513218543629179E-17;
  // 'Jacobi_final_link:270' t213 = t102.*3.84e-1;
  t213 = t102 * 0.384;
  // 'Jacobi_final_link:271' t214 = t103.*3.84e-1;
  t214 = t103 * 0.384;
  // 'Jacobi_final_link:272' t259 = t88+t110+t144;
  t259_tmp = t11 * theta6;
  theta2 = (t88 - theta2) + t259_tmp * 6.123233995736766E-17;
  // 'Jacobi_final_link:273' t262 = t6.*t258.*6.123233995736766e-17;
  // 'Jacobi_final_link:274' t263 = t12.*t258.*6.123233995736766e-17;
  // 'Jacobi_final_link:275' t271 = t6.*t269;
  t271 = t6 * t269;
  // 'Jacobi_final_link:276' t272 = t12.*t269;
  // 'Jacobi_final_link:277' t274 = t6.*t258.*4.011857418620469e-34;
  t274_tmp = t6 * t258;
  t335 = t274_tmp * 4.011857418620469E-34;
  // 'Jacobi_final_link:278' t301 = t53+t70+t74+t78+t258+1.405799628556214e-65;
  t301 = ((((-(t23 * 6.123233995736766E-17) + t70) - t71) + t4 * t70) + t258) +
         1.405799628556214E-65;
  // 'Jacobi_final_link:279' t116 = -t113;
  // 'Jacobi_final_link:280' t117 = -t115;
  // 'Jacobi_final_link:281' t155 = t22+t66+t92;
  theta1 = (t22 - t63) + t36 * t57;
  // 'Jacobi_final_link:282' t161 = -t158;
  // 'Jacobi_final_link:283' t162 = t157.*(3.3e+1./4.0e+2);
  t162 = t157 * 0.0825;
  // 'Jacobi_final_link:284' t193 = t5.*t150.*6.123233995736766e-17;
  // 'Jacobi_final_link:285' t194 = t11.*t150.*6.123233995736766e-17;
  // 'Jacobi_final_link:286' t196 = t158.*6.123233995736766e-17;
  // 'Jacobi_final_link:287' t200 = t5.*t156.*6.123233995736766e-17;
  // 'Jacobi_final_link:288' t201 = t11.*t156.*6.123233995736766e-17;
  // 'Jacobi_final_link:289' t202 = t11.*t150.*5.051668046482832e-18;
  t202_tmp = t11 * theta4;
  t202 = t202_tmp * 5.0516680464828323E-18;
  // 'Jacobi_final_link:290' t204 = t11.*t156.*5.051668046482832e-18;
  t204_tmp = t11 * theta3;
  t204 = t204_tmp * 5.0516680464828323E-18;
  // 'Jacobi_final_link:291' t229 = t5.*t150.*3.749399456654644e-33;
  // 'Jacobi_final_link:292' t231 = t158.*4.011857418620469e-34;
  // 'Jacobi_final_link:293' t232 = t5.*t156.*3.749399456654644e-33;
  // 'Jacobi_final_link:294' t248 = t158.*3.84e-1;
  t248 = t158 * 0.384;
  // 'Jacobi_final_link:295' t251 = t5.*t150.*2.45655417317456e-50;
  // 'Jacobi_final_link:296' t253 = t5.*t156.*2.45655417317456e-50;
  // 'Jacobi_final_link:297' t255 = t5.*t150.*2.351321854362918e-17;
  t255_tmp = t5 * theta4;
  t255 = t255_tmp * 2.3513218543629179E-17;
  // 'Jacobi_final_link:298' t257 = t5.*t156.*2.351321854362918e-17;
  t257_tmp = t5 * theta3;
  t257 = t257_tmp * 2.3513218543629179E-17;
  // 'Jacobi_final_link:299' t260 = t6.*t259;
  // 'Jacobi_final_link:300' t261 = t12.*t259;
  t261 = t12 * theta2;
  // 'Jacobi_final_link:301' t264 = t43+t75+t80+t150;
  t264 = ((t43 - t8 * 3.749399456654644E-33) + t17 * 3.749399456654644E-33) +
         theta4;
  // 'Jacobi_final_link:302' t265 = -t262;
  // 'Jacobi_final_link:303' t273 = -t272;
  // 'Jacobi_final_link:304' t275 = -t274;
  // 'Jacobi_final_link:305' t277 = t271.*6.55186037543834e-18;
  t277 = t271 * 6.55186037543834E-18;
  // 'Jacobi_final_link:306' t302 = t13.*t301.*(1.1e+1./1.25e+2);
  t302 = t13 * t301 * 0.088;
  // 'Jacobi_final_link:307' t303 = t7.*t301.*(1.07e+2./1.0e+3);
  t303_tmp_tmp = t7 * t301;
  t333 = t303_tmp_tmp * 0.107;
  // 'Jacobi_final_link:308' t159 = t5.*t155;
  t159 = t5 * theta1;
  // 'Jacobi_final_link:309' t160 = t11.*t155;
  t160 = t11 * theta1;
  // 'Jacobi_final_link:310' t165 = -t162;
  // 'Jacobi_final_link:311' t195 = -t193;
  // 'Jacobi_final_link:312' t197 = -t196;
  // 'Jacobi_final_link:313' t208 = -t204;
  // 'Jacobi_final_link:314' t230 = -t229;
  // 'Jacobi_final_link:315' t233 = -t231;
  // 'Jacobi_final_link:316' t250 = -t248;
  // 'Jacobi_final_link:317' t252 = -t251;
  // 'Jacobi_final_link:318' t256 = -t255;
  // 'Jacobi_final_link:319' t266 = t261.*6.55186037543834e-18;
  t266 = t261 * 6.55186037543834E-18;
  // 'Jacobi_final_link:320' t267 = t6.*t264;
  t267 = t6 * t264;
  // 'Jacobi_final_link:321' t268 = t12.*t264;
  // 'Jacobi_final_link:322' t279 = t104+t157+t201;
  theta4 = (t104 + t157) + t204_tmp * 6.123233995736766E-17;
  // 'Jacobi_final_link:323' t281 = t102+t161+t200;
  theta5 = (t102 - t158) + t257_tmp * 6.123233995736766E-17;
  // 'Jacobi_final_link:324' t304 = -t303;
  // 'Jacobi_final_link:325' t305 = t245+t261+t265;
  theta3 = (t245 + t261) - t274_tmp * 6.123233995736766E-17;
  // 'Jacobi_final_link:326' t306 = t247+t260+t263;
  theta1 = (-(t12 * t244) + t6 * theta2) + t12 * t258 * 6.123233995736766E-17;
  // 'Jacobi_final_link:327' t166 = t159.*(3.3e+1./4.0e+2);
  t166 = t159 * 0.0825;
  // 'Jacobi_final_link:328' t198 = t160.*6.123233995736766e-17;
  // 'Jacobi_final_link:329' t234 = t160.*4.011857418620469e-34;
  // 'Jacobi_final_link:330' t249 = t160.*3.84e-1;
  t249 = t160 * 0.384;
  // 'Jacobi_final_link:331' t270 = -t267;
  // 'Jacobi_final_link:332' t276 = t267.*6.55186037543834e-18;
  t276 = t267 * 6.55186037543834E-18;
  // 'Jacobi_final_link:333' t278 = t103+t160+t195;
  t258 = (t103 + t160) - t255_tmp * 6.123233995736766E-17;
  // 'Jacobi_final_link:334' t280 = t111+t159+t194;
  t5 = (-t106 + t159) + t202_tmp * 6.123233995736766E-17;
  // 'Jacobi_final_link:335' t282 = t6.*t279;
  // 'Jacobi_final_link:336' t283 = t12.*t279;
  t283 = t12 * theta4;
  // 'Jacobi_final_link:337' t293 = t6.*t281.*6.123233995736766e-17;
  // 'Jacobi_final_link:338' t294 = t12.*t281.*6.123233995736766e-17;
  // 'Jacobi_final_link:339' t299 = t6.*t281.*4.011857418620469e-34;
  t299_tmp = t6 * theta5;
  t299 = t299_tmp * 4.011857418620469E-34;
  // 'Jacobi_final_link:340' t307 = t7.*t306.*(1.1e+1./1.25e+2);
  t11 = t7 * theta1 * 0.088;
  // 'Jacobi_final_link:341' t308 = t13.*t306.*(1.07e+2./1.0e+3);
  t308_tmp = t13 * theta1;
  theta6 = t308_tmp * 0.107;
  // 'Jacobi_final_link:342' t309 = t13.*t305.*5.388445916248354e-18;
  t70 = t13 * theta3 * 5.3884459162483537E-18;
  // 'Jacobi_final_link:343' t311 = t7.*t305.*6.55186037543834e-18;
  t311_tmp = t7 * theta3;
  t43 = t311_tmp * 6.55186037543834E-18;
  // 'Jacobi_final_link:344' t313 = t50+t82+t93+t118+t130+t140+t281;
  t313 = (((((-(t15 * 6.123233995736766E-17) + t21 * 3.749399456654644E-33) +
             t36 * t58) +
            t2 * 2.2958450216584679E-49) -
           t14 * 2.2958450216584679E-49) +
          t237_tmp * -3.749399456654644E-33) +
         theta5;
  // 'Jacobi_final_link:345' et41 = t86+t119+t122+t125+t135+t145+t183+t305;
  et41 = ((((((-(t23 * 3.749399456654644E-33) + t119) - t120) + t4 * t119) +
            t87 * 6.123233995736766E-17) +
           t107 * 6.123233995736766E-17) +
          t238_tmp * 3.749399456654644E-33) +
         theta3;
  // 'Jacobi_final_link:346' et42 = 8.608040076769528e-82;
  // 'Jacobi_final_link:347' t336 = et41+et42;
  // 'Jacobi_final_link:348' t284 = t6.*t280;
  // 'Jacobi_final_link:349' t285 = t12.*t280;
  t285 = t12 * t5;
  // 'Jacobi_final_link:350' t287 = t6.*t278.*6.123233995736766e-17;
  t287_tmp = t6 * t258;
  t58 = t287_tmp * 6.123233995736766E-17;
  // 'Jacobi_final_link:351' t288 = t12.*t278.*6.123233995736766e-17;
  // 'Jacobi_final_link:352' t291 = t283.*6.55186037543834e-18;
  t291 = t283 * 6.55186037543834E-18;
  // 'Jacobi_final_link:353' t296 = -t293;
  // 'Jacobi_final_link:354' t297 = t6.*t278.*4.011857418620469e-34;
  t297 = t287_tmp * 4.011857418620469E-34;
  // 'Jacobi_final_link:355' t300 = -t299;
  // 'Jacobi_final_link:356' t310 = -t309;
  // 'Jacobi_final_link:357' t312 = t45+t79+t97+t123+t127+t136+t278;
  t312 = (((((t19 * 6.123233995736766E-17 + t16 * 3.749399456654644E-33) +
             t36 * t59) -
            t8 * 2.2958450216584679E-49) +
           t17 * 2.2958450216584679E-49) +
          t57 * t71) +
         t258;
  // 'Jacobi_final_link:358' t317 = t13.*t313.*(1.1e+1./1.25e+2);
  t317_tmp = t13 * t313;
  t317 = t317_tmp * 0.088;
  // 'Jacobi_final_link:359' t318 = t7.*t313.*(1.07e+2./1.0e+3);
  t318_tmp = t7 * t313;
  t318 = t318_tmp * 0.107;
  // 'Jacobi_final_link:360' t323 = t273+t282+t294;
  theta1 = (-(t12 * t269) + t6 * theta4) + t12 * theta5 * 6.123233995736766E-17;
  // 'Jacobi_final_link:361' t286 = -t285;
  // 'Jacobi_final_link:362' t289 = -t287;
  // 'Jacobi_final_link:363' t290 = -t288;
  // 'Jacobi_final_link:364' t292 = t285.*6.55186037543834e-18;
  t292 = t285 * 6.55186037543834E-18;
  // 'Jacobi_final_link:365' t298 = -t297;
  // 'Jacobi_final_link:366' t314 = t13.*t312.*(1.1e+1./1.25e+2);
  t314_tmp = t13 * t312;
  t314 = t314_tmp * 0.088;
  // 'Jacobi_final_link:367' t315 = t7.*t312.*(1.07e+2./1.0e+3);
  t315_tmp = t7 * t312;
  t315 = t315_tmp * 0.107;
  // 'Jacobi_final_link:368' t319 = -t318;
  // 'Jacobi_final_link:369' t321 = t270+t285+t287;
  theta2 = (-t267 + t285) + t58;
  // 'Jacobi_final_link:370' t322 = t271+t283+t296;
  theta4 = (t271 + t283) - t299_tmp * 6.123233995736766E-17;
  // 'Jacobi_final_link:371' t328 = t7.*t323.*(1.1e+1./1.25e+2);
  t328_tmp = t7 * theta1;
  t328 = t328_tmp * 0.088;
  // 'Jacobi_final_link:372' t329 = t13.*t323.*(1.07e+2./1.0e+3);
  t329_tmp = t13 * theta1;
  t329 = t329_tmp * 0.107;
  // 'Jacobi_final_link:373' et43 =
  // t134+t171+t173+t176+t177+t186+t219+t254+t266+t275+t302+t304+t307+t308+t310+t311;
  et43 =
      ((((((((((((((-(t23 * 2.45655417317456E-50) + t171) - t172) + t4 * t171) +
                 t87 * 4.011857418620469E-34) +
                t107 * 4.011857418620469E-34) +
               t238_tmp * 2.45655417317456E-50) +
              t254) +
             t266) -
            t335) +
           t302) -
          t333) +
         t11) +
        theta6) -
       t70) +
      t43;
  // 'Jacobi_final_link:374' et44 = 5.639867668917148e-99;
  // 'Jacobi_final_link:375' t339 = et43+et44;
  // 'Jacobi_final_link:376' et45 =
  // t90+t114+t147+t154+t187+t189+t192+t199+t215+t238+t254+t266+t275+t302+t304+t307+t308+t310+t311;
  theta1 = t259_tmp * 5.0516680464828323E-18;
  t187 = (((((((((((((((((-(t88 * 0.0825) + t114) - theta1) -
                        t23 * 2.3513218543629179E-17) +
                       t187) -
                      t188) +
                     t192) +
                    t199) +
                   t215) +
                  t238) +
                 t254) +
                t266) -
               t335) +
              t302) -
             t333) +
            t11) +
           theta6) -
          t70) +
         t43;
  // 'Jacobi_final_link:377' et46 = 5.398270573655862e-66;
  // 'Jacobi_final_link:378' t340 = et45+et46;
  // 'Jacobi_final_link:379' et47 =
  // t30+t54+t56+t90+t114+t147+t154+t189+t192+t199+t215+t220+t238+t254+t266+t275+t302+t304+t307+t308+t310+t311;
  // 'Jacobi_final_link:380' et48 = 1.184810228302868e-33;
  // 'Jacobi_final_link:381' t342 = et47+et48;
  theta3 = (-(t20 * 0.0825) + t54) + t3 * t10 * -5.0516680464828323E-18;
  t114 = (((((((((((((((((((theta3 - t88 * 0.0825) + t114) - theta1) -
                         t23 * 2.3513218543629179E-17) -
                        t188) +
                       t192) +
                      t199) +
                     t215) +
                    t3 * 0.316) +
                   t238) +
                  t254) +
                 t266) -
                t335) +
               t302) -
              t333) +
             t11) +
            theta6) -
           t70) +
          t43) +
         1.184810228302868E-33;
  // 'Jacobi_final_link:382' t295 = -t292;
  // 'Jacobi_final_link:383' t316 = -t315;
  // 'Jacobi_final_link:384' t320 = t268+t284+t290;
  theta1 = (t12 * t264 + t6 * t5) - t12 * t258 * 6.123233995736766E-17;
  // 'Jacobi_final_link:385' t330 = t13.*t321.*5.388445916248354e-18;
  t171 = t13 * theta2;
  t36 = t171 * 5.3884459162483537E-18;
  // 'Jacobi_final_link:386' t331 = t7.*t321.*6.55186037543834e-18;
  t266 = t7 * theta2;
  t119 = t266 * 6.55186037543834E-18;
  // 'Jacobi_final_link:387' t333 = t13.*t322.*5.388445916248354e-18;
  t302 = t13 * theta4;
  t333 = t302 * 5.3884459162483537E-18;
  // 'Jacobi_final_link:388' t335 = t7.*t322.*6.55186037543834e-18;
  t259_tmp = t7 * theta4;
  t335 = t259_tmp * 6.55186037543834E-18;
  // 'Jacobi_final_link:389' t337 =
  // t81+t126+t138+t143+t167+t169+t178+t198+t230+t267+t286+t289;
  t71 = ((((((((((t19 * 3.749399456654644E-33 + t16 * 2.2958450216584679E-49) +
                 t64 * 3.749399456654644E-33) +
                t103 * 6.123233995736766E-17) -
               t8 * 1.405799628556214E-65) +
              t17 * 1.405799628556214E-65) +
             t57 * t120) +
            t160 * 6.123233995736766E-17) -
           t255_tmp * 3.749399456654644E-33) +
          t267) -
         t285) -
        t58;
  // 'Jacobi_final_link:390' t338 =
  // t85+t128+t137+t141+t163+t170+t182+t197+t232+t322;
  t59 = ((((((((-(t15 * 3.749399456654644E-33) + t21 * 2.2958450216584679E-49) +
               t62 * 3.749399456654644E-33) +
              t102 * 6.123233995736766E-17) +
             t2 * 1.405799628556214E-65) -
            t14 * 1.405799628556214E-65) +
           t237_tmp * -2.2958450216584679E-49) -
          t158 * 6.123233995736766E-17) +
         t257_tmp * 3.749399456654644E-33) +
        theta4;
  // 'Jacobi_final_link:391' t341 = t30+t54+t56+t340;
  t58 = theta3 + (t187 + 5.3982705736558617E-66);
  // 'Jacobi_final_link:392' t324 = t7.*t320.*(1.1e+1./1.25e+2);
  t5 = t7 * theta1;
  theta3 = t5 * 0.088;
  // 'Jacobi_final_link:393' t326 = t13.*t320.*(1.07e+2./1.0e+3);
  t43 = t13 * theta1;
  theta2 = t43 * 0.107;
  // 'Jacobi_final_link:394' t332 = -t331;
  // 'Jacobi_final_link:395' t334 = -t333;
  // 'Jacobi_final_link:396' t325 = -t324;
  // 'Jacobi_final_link:397' t327 = -t326;
  // 'Jacobi_final_link:398' t344 =
  // t133+t175+t179+t184+t205+t212+t218+t233+t253+t277+t291+t300+t317+t319+t328+t329+t334+t335;
  t11 = ((((((((((((((((-(t15 * 2.45655417317456E-50) +
                        t21 * 1.504205602555149E-66) +
                       t62 * 2.45655417317456E-50) +
                      t102 * 4.011857418620469E-34) +
                     t2 * 9.2106028821433953E-83) -
                    t14 * 9.2106028821433953E-83) +
                   t237_tmp * -1.504205602555149E-66) -
                  t158 * 4.011857418620469E-34) +
                 t257_tmp * 2.45655417317456E-50) +
                t277) +
               t291) -
              t299) +
             t317) -
            t318) +
           t328) +
          t329) -
         t333) +
        t335;
  // 'Jacobi_final_link:399' t346 =
  // t116+t152+t165+t191+t203+t208+t213+t223+t228+t237+t250+t257+t277+t291+t300+t317+t319+t328+t329+t334+t335;
  t258 =
      (((((((((((((((((((-t113 - t148) - t162) + t21 * 1.439769391355383E-33) +
                      t203) -
                     t204) +
                    t213) +
                   t2 * 8.8160448831685167E-50) -
                  t14 * 8.8160448831685167E-50) +
                 t237) -
                t248) +
               t257) +
              t277) +
             t291) -
            t299) +
           t317) -
          t318) +
         t328) +
        t329) -
       t333) +
      t335;
  // 'Jacobi_final_link:400' t343 =
  // t131+t174+t181+t185+t209+t211+t216+t234+t252+t276+t295+t298+t314+t316+t325+t327+t330+t332;
  theta6 = ((((((((((((((((t19 * 2.45655417317456E-50 +
                           t16 * 1.504205602555149E-66) +
                          t64 * 2.45655417317456E-50) +
                         t103 * 4.011857418620469E-34) -
                        t8 * 9.2106028821433953E-83) +
                       t17 * 9.2106028821433953E-83) +
                      t57 * t172) +
                     t160 * 4.011857418620469E-34) -
                    t255_tmp * 2.45655417317456E-50) +
                   t276) -
                  t292) -
                 t297) +
                t314) -
               t315) -
              theta3) -
             theta2) +
            t36) -
           t119;
  // 'Jacobi_final_link:401' t345 =
  // t117+t149+t166+t190+t202+t207+t214+t225+t227+t235+t249+t256+t276+t295+t298+t314+t316+t325+t327+t330+t332;
  t70 =
      (((((((((((((((((((-t115 + t149) + t166) + t16 * 1.439769391355383E-33) +
                      t202) +
                     t207) +
                    t214) -
                   t8 * 8.8160448831685167E-50) +
                  t17 * 8.8160448831685167E-50) +
                 t235) +
                t249) -
               t255) +
              t276) -
             t292) -
            t297) +
           t314) -
          t315) -
         theta3) -
        theta2) +
       t36) -
      t119;
  // 'Jacobi_final_link:402' t348 = t27+t67+t112+t346;
  theta4 = (t27 + t67) + t54 * t60;
  theta5 = theta4 + t258;
  // 'Jacobi_final_link:403' t349 =
  // t31+t68+t109+t117+t149+t166+t202+t207+t214+t221+t235+t241+t243+t249+t256+t276+t295+t298+t314+t316+t325+t327+t330+t332;
  theta1 =
      (-(t22 * 0.0825) + t63 * 0.0825) + t109_tmp * -5.0516680464828323E-18;
  theta3 = ((((((((((((((((((((theta1 - t115) + t149) + t166) + t202) + t207) +
                          t214) +
                         t16 * 0.316) +
                        t235) -
                       t8 * 1.9349419426528181E-17) +
                      t17 * 1.9349419426528181E-17) +
                     t249) -
                    t255) +
                   t276) -
                  t292) -
                 t297) +
                t314) -
               t315) -
              theta3) -
             theta2) +
            t36) -
           t119;
  // 'Jacobi_final_link:404' t347 = t31+t68+t109+t345;
  theta2 = theta1 + t70;
  // 'Jacobi_final_link:405' et49 = t2;
  // 'Jacobi_final_link:406' et50 = -1.184810228302868e-33;
  // 'Jacobi_final_link:407' et51 = t14;
  // 'Jacobi_final_link:408' et52 = 1.184810228302868e-33;
  // 'Jacobi_final_link:409' et53 = t15;
  // 'Jacobi_final_link:410' et54 = 1.439769391355383e-33;
  // 'Jacobi_final_link:411' et55 = t21;
  // 'Jacobi_final_link:412' et56 = -1.934941942652818e-17;
  // 'Jacobi_final_link:413' et57 = t62;
  // 'Jacobi_final_link:414' et58 = -1.439769391355383e-33;
  // 'Jacobi_final_link:415' et59 = t4.*t60;
  // 'Jacobi_final_link:416' et60 = 8.816044883168516e-50;
  // 'Jacobi_final_link:417' et61 = t5.*t156;
  // 'Jacobi_final_link:418' et62 = -1.439769391355383e-33;
  // 'Jacobi_final_link:419' et63 =
  // et49.*et50+et51.*et52+et53.*et54-t18.*5.051668046482832e-18+et55.*et56-t61.*5.051668046482832e-18+et57.*et58;
  // 'Jacobi_final_link:420' et64 = t102.*(-2.351321854362918e-17);
  // 'Jacobi_final_link:421' et65 =
  // t104.*5.051668046482832e-18+t157.*5.051668046482832e-18;
  // 'Jacobi_final_link:422' et66 = t158.*2.351321854362918e-17;
  // 'Jacobi_final_link:423' et67 = t271.*(-4.011857418620469e-34);
  // 'Jacobi_final_link:424' et68 = t283.*(-4.011857418620469e-34)+et59.*et60;
  // 'Jacobi_final_link:425' et69 =
  // t10.*t60.*(-3.093254551740081e-34)+et61.*et62; 'Jacobi_final_link:426' et70
  // = t11.*t156.*3.093254551740081e-34; 'Jacobi_final_link:427' et71 =
  // t6.*t281.*2.45655417317456e-50; 'Jacobi_final_link:428' et72 =
  // t7.*t313.*6.55186037543834e-18-t13.*t313.*5.388445916248354e-18;
  // 'Jacobi_final_link:429' et73 =
  // t7.*t322.*(-4.011857418620469e-34)-t7.*t323.*5.388445916248354e-18;
  // 'Jacobi_final_link:430' et74 =
  // t13.*t322.*3.299471521856087e-34-t13.*t323.*6.55186037543834e-18+t2.*t342;
  // 'Jacobi_final_link:431' et75 = t8;
  // 'Jacobi_final_link:432' et76 = -1.184810228302868e-33;
  // 'Jacobi_final_link:433' et77 = t16;
  // 'Jacobi_final_link:434' et78 = 1.934941942652818e-17;
  // 'Jacobi_final_link:435' et79 = t17;
  // 'Jacobi_final_link:436' et80 = 1.184810228302868e-33;
  // 'Jacobi_final_link:437' et81 = t19;
  // 'Jacobi_final_link:438' et82 = 1.439769391355383e-33;
  // 'Jacobi_final_link:439' et83 = t64;
  // 'Jacobi_final_link:440' et84 = 1.439769391355383e-33;
  // 'Jacobi_final_link:441' et85 = t4.*t57;
  // 'Jacobi_final_link:442' et86 = 8.816044883168516e-50;
  // 'Jacobi_final_link:443' et87 = t5.*t150;
  // 'Jacobi_final_link:444' et88 = -1.439769391355383e-33;
  // 'Jacobi_final_link:445' et89 =
  // et75.*et76+et77.*et78+et79.*et80+et81.*et82-t22.*5.051668046482832e-18+t63.*5.051668046482832e-18+et83.*et84;
  // 'Jacobi_final_link:446' et90 = t103.*2.351321854362918e-17;
  // 'Jacobi_final_link:447' et91 =
  // t106.*(-5.051668046482832e-18)+t159.*5.051668046482832e-18;
  // 'Jacobi_final_link:448' et92 = t160.*2.351321854362918e-17;
  // 'Jacobi_final_link:449' et93 = t267.*4.011857418620469e-34;
  // 'Jacobi_final_link:450' et94 = t285.*(-4.011857418620469e-34)+et85.*et86;
  // 'Jacobi_final_link:451' et95 =
  // t10.*t57.*(-3.093254551740081e-34)+et87.*et88; 'Jacobi_final_link:452' et96
  // = t11.*t150.*3.093254551740081e-34; 'Jacobi_final_link:453' et97 =
  // t6.*t278.*(-2.45655417317456e-50); 'Jacobi_final_link:454' et98 =
  // t7.*t312.*(-6.55186037543834e-18)+t13.*t312.*5.388445916248354e-18-t7.*t320.*5.388445916248354e-18;
  // 'Jacobi_final_link:455' et99 =
  // t7.*t321.*(-4.011857418620469e-34)-t13.*t320.*6.55186037543834e-18;
  // 'Jacobi_final_link:456' et100 = t13.*t321.*3.299471521856087e-34+t8.*t342;
  // 'Jacobi_final_link:457' et101 = t8;
  // 'Jacobi_final_link:458' et102 = -8.608040076769528e-82;
  // 'Jacobi_final_link:459' et103 = t17;
  // 'Jacobi_final_link:460' et104 = 8.608040076769528e-82;
  // 'Jacobi_final_link:461' et105 =
  // et101.*et102+t16.*1.405799628556214e-65+et103.*et104;
  // 'Jacobi_final_link:462' et106 = t19.*2.295845021658468e-49;
  // 'Jacobi_final_link:463' et107 = t64.*2.295845021658468e-49;
  // 'Jacobi_final_link:464' et108 =
  // t103.*3.749399456654644e-33+t160.*3.749399456654644e-33;
  // 'Jacobi_final_link:465' et109 =
  // t267.*6.123233995736766e-17-t285.*6.123233995736766e-17;
  // 'Jacobi_final_link:466' et110 = t4.*t57.*1.405799628556214e-65;
  // 'Jacobi_final_link:467' et111 = t5.*t150.*(-2.295845021658468e-49);
  // 'Jacobi_final_link:468' et112 =
  // t6.*t278.*(-3.749399456654644e-33)-t7.*t312-t7.*t321.*6.123233995736766e-17-t13.*t320;
  // 'Jacobi_final_link:469' et113 = t2;
  // 'Jacobi_final_link:470' et114 = 8.608040076769528e-82;
  // 'Jacobi_final_link:471' et115 = t14;
  // 'Jacobi_final_link:472' et116 = -8.608040076769528e-82;
  // 'Jacobi_final_link:473' et117 =
  // et113.*et114+et115.*et116-t15.*2.295845021658468e-49;
  // 'Jacobi_final_link:474' et118 = t21.*1.405799628556214e-65;
  // 'Jacobi_final_link:475' et119 = t62.*2.295845021658468e-49;
  // 'Jacobi_final_link:476' et120 = t102.*3.749399456654644e-33;
  // 'Jacobi_final_link:477' et121 =
  // t158.*(-3.749399456654644e-33)+t271.*6.123233995736766e-17;
  // 'Jacobi_final_link:478' et122 = t283.*6.123233995736766e-17;
  // 'Jacobi_final_link:479' et123 = t4.*t60.*(-1.405799628556214e-65);
  // 'Jacobi_final_link:480' et124 = t5.*t156.*2.295845021658468e-49;
  // 'Jacobi_final_link:481' et125 =
  // t6.*t281.*(-3.749399456654644e-33)-t7.*t313+t7.*t322.*6.123233995736766e-17+t13.*t323;
  // 'Jacobi_final_link:482' et126 = t3.*1.405799628556214e-65;
  // 'Jacobi_final_link:483' et127 = t4.*(-1.405799628556214e-65);
  // 'Jacobi_final_link:484' et128 = t23.*(-2.295845021658468e-49);
  // 'Jacobi_final_link:485' et129 =
  // t87.*3.749399456654644e-33+t107.*3.749399456654644e-33;
  // 'Jacobi_final_link:486' et130 =
  // t245.*6.123233995736766e-17+t261.*6.123233995736766e-17;
  // 'Jacobi_final_link:487' et131 = t3.*t4.*1.405799628556214e-65;
  // 'Jacobi_final_link:488' et132 = t5.*t95.*2.295845021658468e-49;
  // 'Jacobi_final_link:489' et133 =
  // t6.*t258.*(-3.749399456654644e-33)-t7.*t301+t7.*t305.*6.123233995736766e-17+t13.*t306;
  // 'Jacobi_final_link:490' et134 = 5.27090436347397e-98;
  // 'Jacobi_final_link:491' mt1 =
  // [-t27-t67+t113+t148+t162-t203+t204-t213-t222+t236-t239+t242+t248-t257-t277-t291+t299-t317+t318-t328-t329+t333-t335-t10.*t60.*5.051668046482832e-18,t349,0.0,0.0,0.0,1.0,et63+et64+et65+et66+et67+et68+et69+et70+et71+et72+et73+et74,et89+et90+et91+et92+et93+et94+et95+et96+et97+et98+et99+et100,-t2.*t349-t8.*(t27+t67+t112+t116+t152+t165+t203+t208+t213+t222+t237+t239-t242+t250+t257+t277+t291+t300+t317+t319+t328+t329+t334+t335),-t8,t2];
  // 'Jacobi_final_link:492' mt2 =
  // [6.123233995736766e-17,-t72.*t348+t94.*t341,t72.*t347-t96.*t341,-t94.*t347+t96.*t348,t96,t94,t72,-t244.*t346+t269.*t340,t244.*t345-t264.*t340,t264.*t346-t269.*t345,t264,t269,t244,-t301.*t344+t313.*t339,t301.*t343-t312.*t339,t312.*t344-t313.*t343,t312,t313,t301,t338.*t339-t336.*t344,-t337.*t339+t336.*t343,t337.*t344-t338.*t343,t337,t338,t336,0.0,0.0,0.0,et105+et106+et107+et108+et109+et110+et111+et112,et117+et118+et119+et120+et121+et122+et123+et124+et125];
  // 'Jacobi_final_link:493' mt3 =
  // [et126+et127+et128+et129+et130+et131+et132+et133+et134];
  // 'Jacobi_final_link:494' J = reshape([mt1,mt2,mt3],6,7);
  theta1 = t10 * t60;
  J[0] = ((((((((((((((((((((((-t27 - t67) + t113) + t148) + t162) - t203) +
                          t204) -
                         t213) -
                        t222) +
                       t60 * t188) -
                      t239) +
                     t242) +
                    t248) -
                   t257) -
                  t277) -
                 t291) +
                t299) -
               t317) +
              t318) -
             t328) -
            t329) +
           t333) -
          t335) -
         theta1 * 5.0516680464828323E-18;
  J[1] = theta3;
  J[2] = 0.0;
  J[3] = 0.0;
  J[4] = 0.0;
  J[5] = 1.0;
  J[6] =
      ((((((((((((((((t2 * -1.184810228302868E-33 +
                      t14 * 1.184810228302868E-33) +
                     t15 * 1.439769391355383E-33) -
                    t18 * 5.0516680464828323E-18) +
                   t21 * -1.9349419426528181E-17) -
                  t61 * 5.0516680464828323E-18) +
                 t62 * -1.439769391355383E-33) +
                t102 * -2.3513218543629179E-17) +
               (t104 * 5.0516680464828323E-18 +
                t157 * 5.0516680464828323E-18)) +
              t158 * 2.3513218543629179E-17) +
             t271 * -4.011857418620469E-34) +
            (t283 * -4.011857418620469E-34 +
             t237_tmp * 8.8160448831685167E-50)) +
           (theta1 * -3.0932545517400808E-34 +
            t257_tmp * -1.439769391355383E-33)) +
          t204_tmp * 3.0932545517400808E-34) +
         t299_tmp * 2.45655417317456E-50) +
        (t318_tmp * 6.55186037543834E-18 - t317_tmp * 5.3884459162483537E-18)) +
       (t259_tmp * -4.011857418620469E-34 -
        t328_tmp * 5.3884459162483537E-18)) +
      ((t302 * 3.2994715218560868E-34 - t329_tmp * 6.55186037543834E-18) +
       t2 * t114);
  theta1 = t4 * t57;
  J[7] =
      ((((((((((((((((t8 * -1.184810228302868E-33 +
                      t16 * 1.9349419426528181E-17) +
                     t17 * 1.184810228302868E-33) +
                    t19 * 1.439769391355383E-33) -
                   t22 * 5.0516680464828323E-18) +
                  t63 * 5.0516680464828323E-18) +
                 t64 * 1.439769391355383E-33) +
                t103 * 2.3513218543629179E-17) +
               (t106 * -5.0516680464828323E-18 +
                t159 * 5.0516680464828323E-18)) +
              t160 * 2.3513218543629179E-17) +
             t267 * 4.011857418620469E-34) +
            (t285 * -4.011857418620469E-34 + theta1 * 8.8160448831685167E-50)) +
           (t109_tmp * -3.0932545517400808E-34 +
            t255_tmp * -1.439769391355383E-33)) +
          t202_tmp * 3.0932545517400808E-34) +
         t287_tmp * -2.45655417317456E-50) +
        ((t315_tmp * -6.55186037543834E-18 +
          t314_tmp * 5.3884459162483537E-18) -
         t5 * 5.3884459162483537E-18)) +
       (t266 * -4.011857418620469E-34 - t43 * 6.55186037543834E-18)) +
      (t171 * 3.2994715218560868E-34 + t8 * t114);
  J[8] =
      -t2 * theta3 -
      t8 * (((((((((((((((((((((theta4 - t113) - t148) - t162) + t203) - t204) +
                           t213) +
                          t222) +
                         t237) +
                        t239) -
                       t242) -
                      t248) +
                     t257) +
                    t277) +
                   t291) -
                  t299) +
                 t317) -
                t318) +
               t328) +
              t329) -
             t333) +
            t335);
  J[9] = -t8;
  J[10] = t2;
  J[11] = 6.123233995736766E-17;
  J[12] = -(t3 + 3.749399456654644E-33) * theta5 + t94 * t58;
  J[13] = (t3 + 3.749399456654644E-33) * theta2 - t96 * t58;
  J[14] = -t94 * theta2 + t96 * theta5;
  J[15] = t96;
  J[16] = t94;
  J[17] = t3 + 3.749399456654644E-33;
  J[18] = -t244 * t258 + t269 * (t187 + 5.3982705736558617E-66);
  J[19] = t244 * t70 - t264 * (t187 + 5.3982705736558617E-66);
  J[20] = t264 * t258 - t269 * t70;
  J[21] = t264;
  J[22] = t269;
  J[23] = t244;
  J[24] = -t301 * t11 + t313 * (et43 + 5.6398676689171484E-99);
  J[25] = t301 * theta6 - t312 * (et43 + 5.6398676689171484E-99);
  J[26] = t312 * t11 - t313 * theta6;
  J[27] = t312;
  J[28] = t313;
  J[29] = t301;
  J[30] = t59 * (et43 + 5.6398676689171484E-99) -
          (et41 + 8.6080400767695281E-82) * t11;
  J[31] = -t71 * (et43 + 5.6398676689171484E-99) +
          (et41 + 8.6080400767695281E-82) * theta6;
  J[32] = t71 * t11 - t59 * theta6;
  J[33] = t71;
  J[34] = t59;
  J[35] = et41 + 8.6080400767695281E-82;
  J[36] = 0.0;
  J[37] = 0.0;
  J[38] = 0.0;
  J[39] = ((((((((t8 * -8.6080400767695281E-82 + t16 * 1.405799628556214E-65) +
                 t17 * 8.6080400767695281E-82) +
                t19 * 2.2958450216584679E-49) +
               t64 * 2.2958450216584679E-49) +
              (t103 * 3.749399456654644E-33 + t160 * 3.749399456654644E-33)) +
             (t267 * 6.123233995736766E-17 - t285 * 6.123233995736766E-17)) +
            theta1 * 1.405799628556214E-65) +
           t255_tmp * -2.2958450216584679E-49) +
          (((t287_tmp * -3.749399456654644E-33 - t315_tmp) -
            t266 * 6.123233995736766E-17) -
           t43);
  J[40] =
      (((((((((t2 * 8.6080400767695281E-82 + t14 * -8.6080400767695281E-82) -
              t15 * 2.2958450216584679E-49) +
             t21 * 1.405799628556214E-65) +
            t62 * 2.2958450216584679E-49) +
           t102 * 3.749399456654644E-33) +
          (t158 * -3.749399456654644E-33 + t271 * 6.123233995736766E-17)) +
         t283 * 6.123233995736766E-17) +
        t237_tmp * -1.405799628556214E-65) +
       t257_tmp * 2.2958450216584679E-49) +
      (((t299_tmp * -3.749399456654644E-33 - t318_tmp) +
        t259_tmp * 6.123233995736766E-17) +
       t329_tmp);
  J[41] = (((((((t3 * 1.405799628556214E-65 + t4 * -1.405799628556214E-65) +
                t23 * -2.2958450216584679E-49) +
               (t87 * 3.749399456654644E-33 + t107 * 3.749399456654644E-33)) +
              (t245 * 6.123233995736766E-17 + t261 * 6.123233995736766E-17)) +
             t95_tmp * 1.405799628556214E-65) +
            t238_tmp * 2.2958450216584679E-49) +
           (((t274_tmp * -3.749399456654644E-33 - t303_tmp_tmp) +
             t311_tmp * 6.123233995736766E-17) +
            t308_tmp)) +
          5.27090436347397E-98;
}

//
// File trailer for Jacobi_final_link.cpp
//
// [EOF]
//
