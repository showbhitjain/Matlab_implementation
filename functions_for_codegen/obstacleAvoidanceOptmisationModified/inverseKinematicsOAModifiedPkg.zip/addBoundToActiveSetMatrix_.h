//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: addBoundToActiveSetMatrix_.h
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 01-Mar-2025 01:36:28
//

#ifndef ADDBOUNDTOACTIVESETMATRIX__H
#define ADDBOUNDTOACTIVESETMATRIX__H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct d_struct_T;

// Function Declarations
namespace coder {
namespace optim {
namespace coder {
namespace qpactiveset {
namespace WorkingSet {
void addBoundToActiveSetMatrix_(d_struct_T &obj, int idx_local);

void b_addBoundToActiveSetMatrix_(d_struct_T &obj, int idx_local);

} // namespace WorkingSet
} // namespace qpactiveset
} // namespace coder
} // namespace optim
} // namespace coder

#endif
//
// File trailer for addBoundToActiveSetMatrix_.h
//
// [EOF]
//
