d_0 = (d_influence + d_stop)/config.k;
time = 0:ts:waypointTimes(end)-ts ;
joint_Angles_plotmatrix = joint_vector_visualization(:,1:number_of_joints);
max_jointAngles = max(joint_Angles_plotmatrix);
min_jointAngles = min(joint_Angles_plotmatrix);


figure()
subplot(3,2,1)
scatter3(waypoints(1,:), waypoints(2,:), waypoints(3,:), 'o', 'MarkerEdgeColor', [0, 1, 0], 'LineWidth', 2);
hold on;
grid on;
plot3(waypoints(1,:), waypoints(2,:), waypoints(3,:), '.-', 'Color', [0.58, 0, 0.83]);

 xlabel('X-axis'); ylabel('Y-axis'); zlabel('Z-axis');
title('Robot Trajectory Starting and Final State');
for j = 1:length(joint_Angles_plotmatrix)-1:length(joint_Angles_plotmatrix)
linesegments_plot = createLineSegments(mdhparams,robot,radius_of_links,joint_Angles_plotmatrix(j,:));
if j == 1
    plotLineSegments_withcolor(linesegments_plot,[0 1 1]);
else
    plotLineSegments_withcolor(linesegments_plot,[0.23, 0.48, 0.34]);
end

end_effector = getTransform(robot,joint_Angles_plotmatrix(j,:),'robot_link7','base');
end_effector = end_effector(1:3,4);
gripper_tcp = getTransform(robot,joint_Angles_plotmatrix(j,:),'Gripper_TCP','base');
gripper_tcp = gripper_tcp(1:3,4);
hold on;
if j ==1
    plotline(end_effector,gripper_tcp,'Color',[0 1 1])
else
    plotline(end_effector,gripper_tcp,'Color',[0.23, 0.48, 0.34])
end
end
for j = 1:length(obstacles)
plotSphere(obstacles(j).center,obstacles(j).dimensions(1),[0 0 1],0.8);
end





subplot(3,2,2)
scatter3(waypoints(1,:), waypoints(2,:), waypoints(3,:), 'o', 'MarkerEdgeColor', [0, 1, 0], 'LineWidth', 2);
hold on;
grid on;
plot3(waypoints(1,:), waypoints(2,:), waypoints(3,:), '.-', 'Color', [0.58, 0, 0.83]);

 xlabel('X-axis'); ylabel('Y-axis'); zlabel('Z-axis');
 title('Robot Trajectory');
for j = 1:500:length(joint_Angles_plotmatrix)
linesegments_plot = createLineSegments(mdhparams,robot,radius_of_links,joint_Angles_plotmatrix(j,:));

plotLineSegments(linesegments_plot);
 end_effector = getTransform(robot,joint_Angles_plotmatrix(j,:),'robot_link7','base');
end_effector = end_effector(1:3,4);
gripper_tcp = getTransform(robot,joint_Angles_plotmatrix(j,:),'Gripper_TCP','base');
gripper_tcp = gripper_tcp(1:3,4);
hold on;
plotline(end_effector,gripper_tcp)
end
for j = 1:length(obstacles)
plotSphere(obstacles(j).center,obstacles(j).dimensions(1),[0 0 1],0.8);
end

% xlim([-0.1,0.7]);
% ylim([-0.7,0.7]);
% zlim([-0.1,0.7]);
hold off;

subplot(3,2,3)

plot(time,mindistance);

hold on;
grid on;
yline(d_influence, 'r--');  % Red dashed line for d_2 
yline(d_stop, 'g--');  % Green dashed line for d_1 

yline(d_0, 'b--'); % Blue dashed line for d_0 
legend('d_{min}','d_2','d_1','d_0');
xlabel('Time (s)');
ylabel('Distance (m)');
title('d_{min} between Robot and obstacles');
xlim([0 16]);
hold off;

subplot(3,2,4)
plot(time,translational_error(1,1:end));
hold on;
grid on;

plot(time,translational_error(2,1:end));
plot(time,translational_error(3,1:end));
legend('e_x','e_y','e_z');
title('Translational error TCP')
xlabel('Time (s)');
ylabel('Position Error (m)');
xlim([0 16]);
hold off;

subplot(3,2,5)
plot(time,rotational_error(1,1:end));
hold on;
grid on;

plot(time,rotational_error(2,1:end));
plot(time,rotational_error(3,1:end));
legend('e_x','e_y','e_z');
title('Orientation error TCP (axis-angle)')
xlabel('Time (s)');
ylabel('Orientartion Error (rad)');
xlim([0 16]);
hold off;

subplot(3,2,6)
for i = 1:size(desired_joint_velocity,1)
plot(time,desired_joint_velocity(i,1:end-1));
hold on;
grid on;
end 
yline(jointvelMaxValues(1), 'r--');
yline(jointvelMaxValues(6), 'r--');
yline(jointvelMinValues(1), 'b--');
yline(jointvelMinValues(6), 'b--');

legend('$\dot{\theta}_1$','$\dot{\theta}_2$','$\dot{\theta}_3$','$\dot{\theta}_4$','$\dot{\theta}_5$','$\dot{\theta}_6$','$\dot{\theta}_7$','$\dot{\theta}_{max1}$','$\dot{\theta}_{max2}$','$\dot{\theta}_{min1}$','$\dot{\theta}_{min2}$','Interpreter', 'latex');


xlabel('Time (s)');
ylabel('joint velocity (rad/s)');
xlim([0 16]);
hold off;


