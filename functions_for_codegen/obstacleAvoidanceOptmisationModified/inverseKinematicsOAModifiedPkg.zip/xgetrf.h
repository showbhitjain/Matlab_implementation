//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: xgetrf.h
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 01-Mar-2025 01:36:28
//

#ifndef XGETRF_H
#define XGETRF_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace coder {
namespace internal {
namespace lapack {
void xgetrf(double A[36], int ipiv[6]);

}
} // namespace internal
} // namespace coder

#endif
//
// File trailer for xgetrf.h
//
// [EOF]
//
